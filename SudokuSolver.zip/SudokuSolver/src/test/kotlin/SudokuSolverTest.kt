import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.assertDoesNotThrow

internal class SudokuSolverTest {

    @Test
    fun runSolver() {
        val sudokuSolver = SudokuSolver("Puzzle-4x4-0001","UnitTestOutput")
        assertDoesNotThrow { sudokuSolver.runSolver() }
    }
}