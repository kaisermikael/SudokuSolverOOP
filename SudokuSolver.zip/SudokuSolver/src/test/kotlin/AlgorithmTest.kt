import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class AlgorithmStatsTest {

    @Test
    fun addAlgorithm() {
        val algorithmStats = AlgorithmStats
        algorithmStats.addAlgorithm("algorithm1")
        algorithmStats.addAlgorithm("algorithm2")
        algorithmStats.addAlgorithm("algorithm3")
        assertEquals(3, AlgorithmStats.algorithms.size)
        AlgorithmStats.algorithms.clear()
    }

    @Test
    fun getName() {
        val algorithmStats = AlgorithmStats
        algorithmStats.addAlgorithm("algorithm1")
        algorithmStats.addAlgorithm("algorithm2")
        algorithmStats.addAlgorithm("algorithm3")
        assertEquals("algorithm1", AlgorithmStats.algorithms[0].name)
        assertEquals("algorithm2", AlgorithmStats.algorithms[1].name)
        assertEquals("algorithm3", AlgorithmStats.algorithms[2].name)
        AlgorithmStats.algorithms.clear()
    }

    @Test
    fun getSetUseCount() {
        val algorithmStats = AlgorithmStats
        algorithmStats.addAlgorithm("algorithm1")
        algorithmStats.addAlgorithm("algorithm2")
        algorithmStats.addAlgorithm("algorithm3")
        algorithmStats.algorithms[0].useCount = 1
        algorithmStats.algorithms[1].useCount = 2
        algorithmStats.algorithms[2].useCount = 3
        assertEquals(1, AlgorithmStats.algorithms[0].useCount)
        assertEquals(2, AlgorithmStats.algorithms[1].useCount)
        assertEquals(3, AlgorithmStats.algorithms[2].useCount)
        AlgorithmStats.algorithms.clear()
    }

    @Test
    fun getSetUseTime() {
        val algorithmStats = AlgorithmStats
        algorithmStats.addAlgorithm("algorithm1")
        algorithmStats.addAlgorithm("algorithm2")
        algorithmStats.addAlgorithm("algorithm3")
        algorithmStats.algorithms[0].useTime = 1
        algorithmStats.algorithms[1].useTime = 2
        algorithmStats.algorithms[2].useTime = 3
        assertEquals(1, AlgorithmStats.algorithms[0].useTime)
        assertEquals(2, AlgorithmStats.algorithms[1].useTime)
        assertEquals(3, AlgorithmStats.algorithms[2].useTime)
        AlgorithmStats.algorithms.clear()
    }

    @Test
    fun getAlgorithms() {
        val algorithmStats = AlgorithmStats
        algorithmStats.addAlgorithm("algorithm1")
        algorithmStats.addAlgorithm("algorithm2")
        algorithmStats.addAlgorithm("algorithm3")
        assertEquals(3, AlgorithmStats.algorithms.size)
        AlgorithmStats.algorithms.clear()
    }

    @Test
    fun getTotalTime() {
        val algorithmStats = AlgorithmStats
        algorithmStats.addAlgorithm("algorithm1")
        algorithmStats.addAlgorithm("algorithm2")
        algorithmStats.addAlgorithm("algorithm3")
        algorithmStats.algorithms[0].useTime = 1
        algorithmStats.algorithms[1].useTime = 2
        algorithmStats.algorithms[2].useTime = 3
        var totalTime = 0L
        for (algorithm in AlgorithmStats.algorithms) {
            totalTime += algorithm.useTime
        }
        assertEquals(6, totalTime)
        AlgorithmStats.algorithms.clear()
    }

    @Test
    fun updateAlgorithm() {
        val algorithmStats = AlgorithmStats
        algorithmStats.addAlgorithm("algorithm1")
        algorithmStats.addAlgorithm("algorithm2")
        algorithmStats.addAlgorithm("algorithm3")
        algorithmStats.algorithms[0].useCount = 1
        algorithmStats.algorithms[1].useCount = 2
        algorithmStats.algorithms[2].useCount = 3
        algorithmStats.algorithms[0].useTime = 1
        algorithmStats.algorithms[1].useTime = 2
        algorithmStats.algorithms[2].useTime = 3
        algorithmStats.updateAlgorithm("algorithm1", 5)
        algorithmStats.updateAlgorithm("algorithm2", 6)
        algorithmStats.updateAlgorithm("algorithm3", 7)
        assertEquals(2, AlgorithmStats.algorithms[0].useCount)
        assertEquals(3, AlgorithmStats.algorithms[1].useCount)
        assertEquals(4, AlgorithmStats.algorithms[2].useCount)
        assertEquals(6, AlgorithmStats.algorithms[0].useTime)
        assertEquals(8, AlgorithmStats.algorithms[1].useTime)
        assertEquals(10, AlgorithmStats.algorithms[2].useTime)
        AlgorithmStats.algorithms.clear()
    }
}