import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class BoardTest {

    @Test
    fun getSetPossibleSymbols() {
        val boardInput = BoardFileReader.processFile("src/main/resources/SamplePuzzles/Input/Puzzle-4x4-0001.txt")
        val board = BoardFactory(boardInput).createBoard()

        val expectedPossibleSymbols = listOf("1", "2", "3", "4")
        assertEquals(expectedPossibleSymbols, board.possibleSymbols)
    }

    @Test
    fun getWidth() {
        val boardInput = BoardFileReader.processFile("src/main/resources/SamplePuzzles/Input/Puzzle-4x4-0001.txt")
        val board = BoardFactory(boardInput).createBoard()

        assertEquals(4, board.width)
    }

    @Test
    fun getSetBoardStatus() {
        val boardInput = BoardFileReader.processFile("src/main/resources/SamplePuzzles/Input/Puzzle-4x4-0001.txt")
        val board = BoardFactory(boardInput).createBoard()
        board.setBoardStatus("Test Status")
        val expectedBoardStatus = "Test Status"
        assertEquals(expectedBoardStatus, board.boardStatus)
    }

    @Test
    fun checkIfComplete() {
        val boardInput = BoardFileReader.processFile("src/main/resources/SamplePuzzles/Input/Puzzle-4x4-0001.txt")
        val board = BoardFactory(boardInput).createBoard()

        assertFalse(board.checkIfComplete())
    }

    @Test
    fun setBoardWidth() {
        val boardInput = BoardFileReader.processFile("src/main/resources/SamplePuzzles/Input/Puzzle-4x4-0001.txt")
        val board = BoardFactory(boardInput).createBoard()

        board.setBoardWidth(5)

        assertEquals(5, board.width)
    }

    @Test
    fun setBoardPossibleSymbols() {
        val boardInput = BoardFileReader.processFile("src/main/resources/SamplePuzzles/Input/Puzzle-4x4-0001.txt")
        val board = BoardFactory(boardInput).createBoard()

        val possibleSymbols = listOf("1", "2", "3", "4", "5")
        val ALpossibleSymbols = ArrayList<String>()
            ALpossibleSymbols.addAll(possibleSymbols)
        board.setBoardPossibleSymbols(ArrayList(ALpossibleSymbols))

        assertEquals(ALpossibleSymbols, board.possibleSymbols)
    }


    @Test
    fun updatePossibleValues() {
        val boardInput = BoardFileReader.processFile("src/main/resources/SamplePuzzles/Input/Puzzle-4x4-0001.txt")
        val board = BoardFactory(boardInput).createBoard()

        val expectedPossibleSymbols = listOf("1", "2", "3", "4")
        board.updatePossibleValues()
        assertEquals(expectedPossibleSymbols, board.possibleSymbols)
    }
}