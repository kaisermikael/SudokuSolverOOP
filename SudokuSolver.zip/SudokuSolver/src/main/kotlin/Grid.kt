class Grid {
    val grid = ArrayList<ArrayList<Cell>>()
}