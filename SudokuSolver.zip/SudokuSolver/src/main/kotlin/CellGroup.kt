open class CellGroup {
    var cells = ArrayList<Cell>()
}