object BacktrackStack {
    var stack = mutableListOf<Board>()
}