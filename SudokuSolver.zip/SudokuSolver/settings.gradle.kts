
rootProject.name = "SudokuSolver"

